import React from 'react'

export const Secondshow = (must) => {
  return (
    <div>
        <p>{must}</p>
    </div>
  )
}
