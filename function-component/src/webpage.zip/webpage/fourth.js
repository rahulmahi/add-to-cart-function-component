import React from "react";

function Fourth() {
  return (
    <div className="fourth">
      <div className="fourth-first">
        <div>
          <h2>Sign Up In Minutes</h2>
          <p>
            open an investment account in minutes and get started with as little
            as $10.Get started
          </p>
        </div>
        <div>
          <h2>Earing Mady Easy</h2>
          <p>
            Choose from six simple starting option-sign up deposit & refer .We
            walk care of the best
          </p>
        </div>
        <div>
          <h2>Build Your Team</h2>
          <p>
            we have an excellent affilicate plan with four way income
            opportunity
          </p>
        </div>
      </div>
      <div className="token">
        <h2>Token Sale</h2>
        <p>
          We are worlewide investment company commited to revenue maximization
          and reduction of the financial risks at investing WITH SUPPORT OF OUR
          TOKEN PRESALE PRICE AND GROWTH PRICE
        </p>
      </div>
      <div className="currency">
        <div>
          <h2>We are now listed in below</h2>
          <h2>crypto currency</h2>

          <h1 className="dex">DEX-TRADE</h1>
          <h1 className="dex">CONSBIT</h1>
        </div>
        <div>
          <h1>BIT COIN</h1>
          <p>to currency calculator</p>

          <p>
            cryot exchane rate calculator helps you convert prices online
            between two countries in real time.
          </p>
          <section className="text">
            <section>
              <input type={"text"} placeholder="Enter your amount" /><br />
              <input type={"text"} placeholder="Enter your amount" /><br />
            </section>
            <section>
            <select>
                <option>Bitcoin(BTC)</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </select><br />
              <select>
                <option>US Doller USD(BTC)</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
              </select><br />
              <button>Log in Now</button>
            </section>
          </section>
        </div>
      </div>
    </div>
  );
}

export default Fourth;
