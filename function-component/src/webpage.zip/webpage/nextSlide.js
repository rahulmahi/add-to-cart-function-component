import React from "react";

function NextSlide() {
  return (
    <div className="maindiv">
      <div className="slide">
        <h1>We're Reineventing The Global Crypto Currency Mining.</h1>
        <p>
          our platfoem gives you a newgeneration Crypto currency Minig through
          our payout system
        </p>
        <button>Register</button>
      </div>
      <p className="imge"></p>
    </div>

  )
}

export default NextSlide;
