import React from 'react'

export default function Third() {
  return (
    <div className='third'>
        <h2 className='about'>About  PTTN</h2>
        <p className='about'>Today crypto currency trading become an invetiable part of the world ,there is an environment to create a coin that everyone can use as an alternative currency for the daily trading market .The answer is PATTERN COIN</p>
    </div>
  )
}
